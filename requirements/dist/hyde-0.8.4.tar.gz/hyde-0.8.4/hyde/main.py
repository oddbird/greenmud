#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
The hyde executable
"""
from hyde.engine import Engine

def main():
    """Main"""
    Engine().run()

if __name__ == "__main__":
    main()