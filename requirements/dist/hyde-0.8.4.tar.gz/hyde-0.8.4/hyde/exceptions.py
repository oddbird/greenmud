class HydeException(Exception):
    """
    Base class for exceptions from hyde
    """
    pass
