# -*- coding: utf-8 -*-
"""
Handles hyde version
TODO: Use fabric like versioning scheme
"""
__version__ = '0.8.4'
